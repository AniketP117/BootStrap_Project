let numbers= [50, 65, 56, 71, 81, 33];
let evencount=0;
let oddcount=0;
for (i=0; i < numbers.length; i++)
{
    if (numbers[i] % 2 === 0)
    {
    evencount +=1;
    
    } 
    
    else
    {
    oddcount +=1;
    
    }
}
    console.log(`Even Count: ${evencount} odd Count: ${oddcount}`);
    
    

