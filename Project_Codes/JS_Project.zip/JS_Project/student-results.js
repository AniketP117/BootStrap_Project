let students = [
    { rollNumber: 111, marks: 81 },
    { rollNumber: 222, marks: 75 },
    { rollNumber: 333, marks: 43 },
    { rollNumber: 444, marks: 58 }
];

function Result(marks) {
    if (marks > 79) {
        return "Honors";
    } else if (marks >= 50 && marks <= 79) {
        return "1st Division";
    } else {
        return "Fail";
    }
}

students.forEach(student => {
    console.log(`Roll Number: ${student.rollNumber}, Marks: ${student.marks}, Result: ${Result(student.marks)}`);
});