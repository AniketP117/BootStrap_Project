function createMatrix(n) {
    let matrix = [];
  
    for (let i = 0; i < n; i++) {
      let row = [];
      for (let j = 0; j < n; j++) {
        row.push(i === j ? 1 : 0); 
      }
      matrix.push(row);
    }
  
   
    for (let i = 0; i < n; i++) {
      console.log(matrix[i].join(" "));
    }
  }
  
 
  createMatrix(3);
  