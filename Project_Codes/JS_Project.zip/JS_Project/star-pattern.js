for (let i = 1; i <= 9; i++) {
    let stars = "";
    for (let j = 1; j <= 9; j++) {
      if (j <= i) {
        stars += "*";
      } else {
        stars += " ";
      }
    }
    console.log(stars);
  }
  